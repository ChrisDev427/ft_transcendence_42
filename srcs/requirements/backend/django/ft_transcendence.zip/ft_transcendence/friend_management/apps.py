from django.apps import AppConfig


class FriendManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'friend_management'
